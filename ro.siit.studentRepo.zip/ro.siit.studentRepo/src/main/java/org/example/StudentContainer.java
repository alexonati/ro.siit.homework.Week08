package org.example;

import java.util.TreeSet;

public class StudentContainer{

   public TreeSet<Student> a = new TreeSet<Student>();

};
